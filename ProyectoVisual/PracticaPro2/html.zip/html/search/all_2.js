var searchData=
[
  ['distancia_5fmin_12',['distancia_min',['../class_cjt___clusters.html#a5ab85c2e4808bfeb0c422453fbd61d9f',1,'Cjt_Clusters']]],
  ['documentacio_20de_20la_20practica_2e_13',['Documentacio de la Practica.',['../index.html',1,'']]]
];
