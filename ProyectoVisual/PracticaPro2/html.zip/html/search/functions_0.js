var searchData=
[
  ['afegir_5felement_5ftaula_5fclusters_60',['Afegir_element_taula_clusters',['../class_cjt___clusters.html#a3ea04aead06bee8a427662ed6a6d7d11',1,'Cjt_Clusters']]],
  ['afegir_5felement_5ftaula_5fdistancies_61',['Afegir_element_taula_distancies',['../class_cjt___especies.html#a8604b8d1c2f89d273062cd2b44d75a6d',1,'Cjt_Especies']]]
];
