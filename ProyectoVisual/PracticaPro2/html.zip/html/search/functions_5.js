var searchData=
[
  ['llegeix_5fcjt_5fespecies_83',['Llegeix_cjt_especies',['../class_cjt___especies.html#ab30e0d4757be5c84c95f5b02da44c7e3',1,'Cjt_Especies']]]
];
