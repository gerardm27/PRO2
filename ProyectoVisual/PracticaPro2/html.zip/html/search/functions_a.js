var searchData=
[
  ['servir_111',['servir',['../_doxy_help_8txt.html#ac7aee04df1cdfc8d2cda40aa987aa3e8',1,'servir(&lt; em &gt;...&lt;/em &gt;) - Errors que puguin sorgir en warning(\warning):&#160;DoxyHelp.txt'],['../_mind_this_8txt.html#ac7aee04df1cdfc8d2cda40aa987aa3e8',1,'servir(&lt; em &gt;...&lt;/em &gt;) - Errors que puguin sorgir en warning(\warning):&#160;MindThis.txt']]]
];
