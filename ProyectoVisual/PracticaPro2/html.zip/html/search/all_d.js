var searchData=
[
  ['taula_5fclusters_44',['taula_clusters',['../class_cjt___clusters.html#aecb911511a3bdd9c1913e333bfcb69fb',1,'Cjt_Clusters']]],
  ['taula_5fdistancies_45',['taula_distancies',['../class_cjt___especies.html#a2d05653b0a87d03c857dd02f7f99bf24',1,'Cjt_Especies']]]
];
