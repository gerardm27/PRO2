var searchData=
[
  ['mindthis_2etxt_74',['MindThis.txt',['../_mind_this_8txt.html',1,'']]]
];
