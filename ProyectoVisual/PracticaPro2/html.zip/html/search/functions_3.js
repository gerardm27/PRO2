var searchData=
[
  ['gestiona_5finput_75',['gestiona_input',['../program_8cc.html#a1c1a99a8e87619f86c15bdc6f33e8903',1,'gestiona_input():&#160;program.cc'],['../program_8hh.html#a1c1a99a8e87619f86c15bdc6f33e8903',1,'gestiona_input():&#160;program.cc']]]
];
