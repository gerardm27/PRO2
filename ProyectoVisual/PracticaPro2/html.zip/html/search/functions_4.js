var searchData=
[
  ['imprimeix_5farbre_76',['Imprimeix_arbre',['../class_cjt___clusters.html#a0fe9ac0913e9183d156fe5c7b1711ffe',1,'Cjt_Clusters']]],
  ['imprimeix_5farbre_5ffilogenetic_77',['Imprimeix_arbre_filogenetic',['../class_cjt___clusters.html#ae7027b606fcab665c8e4fc7dc551468d',1,'Cjt_Clusters']]],
  ['imprimeix_5fcjt_5fespecies_78',['Imprimeix_cjt_especies',['../class_cjt___especies.html#abfeceb8357985a8fa7a11c02fc9bd559',1,'Cjt_Especies']]],
  ['imprimeix_5fclusters_79',['Imprimeix_clusters',['../class_cjt___clusters.html#a9d642567cf56394781e61c3905a421ca',1,'Cjt_Clusters']]],
  ['imprimeix_5ftaula_5fclusters_80',['Imprimeix_taula_clusters',['../class_cjt___clusters.html#a829856e036f38eed7dbcc1981855ce57',1,'Cjt_Clusters']]],
  ['imprimeix_5ftaula_5fdistancies_81',['Imprimeix_taula_distancies',['../class_cjt___especies.html#af5610671b9693fd0a151c4cfd3abda41',1,'Cjt_Especies']]],
  ['inicialitza_5fclusters_82',['Inicialitza_clusters',['../class_cjt___clusters.html#a4bcb0818445570ca22ad8295f6d744b9',1,'Cjt_Clusters']]]
];
